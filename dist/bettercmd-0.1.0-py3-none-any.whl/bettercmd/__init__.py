from .core import beautify

__all__ = ["beautify"]
